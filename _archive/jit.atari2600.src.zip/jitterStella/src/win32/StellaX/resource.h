//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by StellaX.rc
//
#define IDB_TILE                        101
#define IDI_APP                         102
#define IDD_ABOUT                       103
#define IDD_MAIN                        104
#define IDD_ABOUT_PAGE                  106
#define IDD_CONFIG_PAGE                 108
#define IDS_ALREADYRUNNING              200
#define IDS_CANTOPEN                    204
#define IDS_CW_FAILED                   208
#define IDS_FATALERROR                  275
#define IDS_FILENAME                    277
#define IDS_MANUFACTURER                278
#define IDS_NAME                        280
#define IDS_OUTOFMEMORY                 283
#define IDS_RARITY                      284
#define IDS_STATUSTEXT                  289
#define IDS_STELLA                      290
#define IDS_UNKNOWNERROR                291
#define IDS_NO_CACHE_FILE               291
#define IDS_DEBUGBUILD                  292
#define IDS_CORRUPT_CACHE_FILE          292
#define IDS_ROMDIR_CHANGED              293
#define IDS_COINIT_FAILED               296
#define IDS_ASS_FAILED                  297
#define IDS_PAS_FAILED                  298
#define IDS_NO_ITEM_SELECTED            305
#define IDC_ABOUT                       1001
#define IDC_EMAIL_MAINTAINER            1002
#define IDC_EMAIL_STELLA                1003
#define IDC_EXIT                        1004
#define IDC_PLAY                        1005
#define IDC_ROMCOUNT                    1006
#define IDC_ROMLIST                     1007
#define IDC_STATIC_TEXT                 1008
#define IDC_TITLE                       1009
#define IDC_WEB_MAINTAINER              1010
#define IDC_WEB_STELLA                  1011
#define IDC_WWW_MAME                    1012
#define IDC_ROMPATH                     1013
#define IDC_ROMNOTE                     1014
#define IDC_CONFIG                      1015
#define IDC_CONFIG2                     1016
#define IDC_PADDLE                      1017
#define IDC_VOLUME                      1019
#define IDC_BROWSE                      1022
#define IDC_EDIT2                       1027
#define IDC_RELOAD                      1028
#define IDC_SNAPSHOT_TYPE               1029
#define IDC_SNAPSHOT_LOCATION           1030
#define IDC_SNAPSHOT_MULTIPLE           1031
#define IDC_SOUND_ENABLE                1032
#define IDC_SOUND_VOLUME                1033
#define IDC_LIST1                       1033
#define IDC_VIDEO                       1034
#define IDC_GL_ASPECT                   1035
#define IDC_GL_FSMAX                    1036
#define IDC_SOUND_VOLUME_SPIN           1044
#define IDC_SOUND_FRAGSIZE              1045
#define IDC_TAB1                        1046
#define ID_FILE_EXIT                    32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        296
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1047
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
