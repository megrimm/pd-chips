/* AboutBoxTextView.h - Header for the
   AboutBoxTextView view class for the
   Macintosh OS X SDL port of Stella
   Mark Grebe <atarimac@cox.net>
*/
/* $Id: AboutBoxTextView.h,v 1.1.1.1 2004/06/16 02:30:30 markgrebe Exp $ */

#import <Cocoa/Cocoa.h>

@interface AboutBoxTextView : NSTextView
{
}
@end
