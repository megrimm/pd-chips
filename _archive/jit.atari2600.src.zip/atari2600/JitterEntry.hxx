#ifndef JITTERENTRY_HXX
#define JITTERENTRY_HXX

int jitterEntry(const char* file);

void Cleanup();

#endif