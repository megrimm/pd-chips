#ifndef _ATARI2600_H
#define _ATARI2600_H

#ifdef __cplusplus
extern "C" {
#endif

#include "jit.common.h"
#include "jit.gl.h"

//Stella is written in C++.  This is how we interface C++ structs from C.



#ifdef __cplusplus
}
#endif

#endif
