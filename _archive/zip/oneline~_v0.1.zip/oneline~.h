// maxus germanus 2011
// Line 27 in online~.c can be replace with any of the following
// EXAMPLE: *out++ = v00;
// EXAMPLE: *out++ = v01;
// etc......
#define v00 t&(t>>4)>>3&t>>7
#define v01 +(((((t>>12)^(t>>12)-2)%11*t)/4|t>>13)&127);
#define v02 ((t*("36364689"[t>>13&7]&15))/12&128);
#define v03 