//
//  autotalent_Tests.m
//  autotalent~Tests
//
//  Created by megrimm on 9/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "autotalent_Tests.h"

@implementation autotalent_Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in autotalent~Tests");
}

@end
