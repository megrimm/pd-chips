//
//  autotalent_Tests.h
//  autotalent~Tests
//
//  Created by megrimm on 9/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface autotalent_Tests : SenTestCase

@end
