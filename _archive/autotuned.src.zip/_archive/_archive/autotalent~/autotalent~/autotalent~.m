//
//  autotalent~.m
//  autotalent~
//
//  Created by megrimm on 9/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "autotalent~.h"

@implementation autotalent_

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

@end
