//
//  autotalent~.h
//  autotalent~
//
//  Created by megrimm on 9/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface autotalent_ : NSObject

@end
