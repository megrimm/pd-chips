
#include "m_pd.h"

/* Max -> Pd porting help */
#define t_pxobject t_object
