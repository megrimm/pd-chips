// maxus germanus 2011
// Line 27 in online~.c can be replace with any of the following
// EXAMPLE: *out++ = v00;
// EXAMPLE: *out++ = v01;
// etc......
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define v100 t&(t>>4)>>3&t>>7
#define v101 +(((((t>>12)^(t>>12)-2)%11*t)/4|t>>13)&127)
#define v102 ((t*("36364689"[t>>13&7]&15))/12&128)
#define v103 (t/1e7*t*t+t)%127|t>>3 //no
#define v104 ((t*5/53) | t*5+(t<<1) //no
#define v105 (t<65536)?((2*t*(t>>11)&(t-1)|(t>>4)-1)%64):(((t%98304)>65536)?((17*t*(t*t>>8)&(t-1)|(t>>7)-1)%128|(t>>4)):((13*t*(2*t>>16)&(t-1)|(t>>8)-1)%32|(t>>4))) //yes
#define v106 (cos(t))+((t>>19&t>>18)|123&t>>13*(sin(t))) //no
#define v107 (((t>>4)|(t%10))+3.3) | (((t%101)|(t>>14))&((t>>7)|(t*t%17*sin(t))))+sin(t) //no
#define v108 sinh(t)+((t>>19&t>>18)|123&t>>13*sinh(t)) //no
#define v109 (t<65536)?((2*t*(t>>11)&(t-1)|(t>>4)-1)%64):(((t%98304)>65536)?((17*t*(2*t>>8)&(t-1)|(t>>6)-1)%64|(t>>4)):((15*t*(2*t>>16)&(t-1)|(t>>8)-1)%64|(t>>4))) //yes
#define v110
#define v111 t&(t>>4)>>3&t>>7
#define v112 ((t*("36364689"[t>>13&7]&15))/12&128);
#define v113 (t/1e7*t*t+t)%127|t>>3;
#define v114 ((t*5/53) | t*5+(t<<1);
#define v115
#define v116
#define v117
#define v118
#define v119
#define v120
#define v121 t&(t>>4)>>3&t>>7
#define v122 ((t*("36364689"[t>>13&7]&15))/12&128);
#define v123 (t/1e7*t*t+t)%127|t>>3;
#define v124 ((t*5/53) | t*5+(t<<1);
#define v125
#define v126
#define v127
#define v128
#define v129
#define v130
#define v131 t&(t>>4)>>3&t>>7
#define v132 ((t*("36364689"[t>>13&7]&15))/12&128);
#define v133 (t/1e7*t*t+t)%127|t>>3;
#define v134 ((t*5/53) | t*5+(t<<1);
#define v135
#define v136
#define v137
#define v138
#define v139
#define v140
#define v141 t&(t>>4)>>3&t>>7
#define v142 ((t*("36364689"[t>>13&7]&15))/12&128);
#define v143 (t/1e7*t*t+t)%127|t>>3;
#define v144 ((t*5/53) | t*5+(t<<1);
#define v145
#define v146
#define v147
#define v148
#define v149
#define v150
#define v151 t&(t>>4)>>3&t>>7
#define v152 ((t*("36364689"[t>>13&7]&15))/12&128);
#define v153 (t/1e7*t*t+t)%127|t>>3;
#define v154 ((t*5/53) | t*5+(t<<1);
#define v155
#define v156
#define v157
#define v158
#define v159
#define v160