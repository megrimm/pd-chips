
//--f0plugins_src

source code and compile files for my supercollider plugins.
see http://www.fredrikolofsson.com/pages/code-sc.html#plugins

to build first install cmake and download the supercollider source via git,
then open terminal and cd to the folder containing this README and do...

> mkdir build
> cd build
> cmake -DSC_PATH=~/supercollider/ -DINSTALL_DESTINATION="/Users/???/Library/Application Support/SuperCollider/Extensions" ..
> make install

edit SC_PATH above to point to your supercollider source directory,
and edit INSTALL_DESTINATION to point to where you want the resulting plugins.


NOTE:
Not tested on Windows. Use the old binaries if problems. They are here...
http://www.fredrikolofsson.com/pages/code-sc.html#plugins

RedInfo will only be built and installed under Mac OSX.

